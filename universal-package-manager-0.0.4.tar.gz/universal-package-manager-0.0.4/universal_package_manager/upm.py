# Third-party imports
import gi
import os

# Initialize GTK
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

# Arrays
package_managers = [
    "apt",
    "dnf",
    "eopkg",
    "flatpak",
    "pacman",
    "zypper"
]

def main():
    print("To be finished")
    # To be finished

main()