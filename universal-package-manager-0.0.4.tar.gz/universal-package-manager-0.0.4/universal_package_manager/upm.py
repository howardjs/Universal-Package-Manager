# Third-party imports
import gi
import os

# Initialize GTK
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

# Arrays
package_managers = [
    "apt",
    "dnf",
    "eopkg",
    "flatpak",
    "pacman",
    "zypper"
]

def main():
    # Initialize window and set properties
    window = Gtk.Window()
    window.set_title("The Universal Package Manager")
    window.set_default_size(800, 600)

    # Create "to be finished" text
    label = Gtk.Label()
    label.set_label("To be finished")

    # Add all widgets
    window.add(label)

    # Set window functions
    window.connect("destroy", Gtk.main_quit)
    window.show_all()

    # Run GTK
    Gtk.main()

# Run main
main()